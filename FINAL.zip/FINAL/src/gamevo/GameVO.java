package gamevo;

public class GameVO {

	private String name;
	public GameVO(String name) {
		this.name=name;
	}
	public GameVO() {}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
